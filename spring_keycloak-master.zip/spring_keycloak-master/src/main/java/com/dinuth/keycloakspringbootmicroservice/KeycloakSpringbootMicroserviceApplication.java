package com.dinuth.keycloakspringbootmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakSpringbootMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakSpringbootMicroserviceApplication.class, args);
	}
}
