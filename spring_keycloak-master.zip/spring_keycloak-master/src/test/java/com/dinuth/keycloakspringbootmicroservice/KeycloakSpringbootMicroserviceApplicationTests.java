package com.dinuth.keycloakspringbootmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakSpringbootMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
