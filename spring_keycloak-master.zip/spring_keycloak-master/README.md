# keycloak-springboot-microservice

Please refer Medium article for more details: 
https://medium.com/@ddezoysa/securing-spring-boot-rest-apis-with-keycloak-1d760b2004e
